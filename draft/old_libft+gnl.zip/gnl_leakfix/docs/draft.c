


v2

bzero
memdel
strchr
strjoin
strlen
strnew
strsub



                // includes libft.h

// size_t		ft_strlen(const char *s);
// char		*ft_strjoin(char const *s1, char const *s2);
// char		*ft_strnew(size_t size);
// void		ft_bzero(void *s, size_t n);
// char		*ft_strchr(const char *s, int c);
// void		ft_memdel(void **ap);
// char		*ft_strsub(char const *s, unsigned int start, size_t len);



// #include "get_next_line.h"
// #include <stdio.h>


            // int      main(int ac, char **av)
// {
// 	(void)ac;
// 	char *line = NULL;
// 	int fd = open(av[1], O_RDONLY);

// 	int ret;
// 	while ((ret = get_next_line(fd, &line)))
// 	{
// 		if (ret == -1)
// 		{
// 			printf("error main");
// 			return (0);
// 		}
// 		printf("%s\n", line);
// 	}
// }


// v1

// bzero
// putendl
// strjoin
// strlen
// strncpy
// strdup
// strnew