/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: edoll <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/11 01:30:57 by edoll             #+#    #+#             */
/*   Updated: 2019/06/11 21:31:10 by edoll            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_atoi(char *str)
{
	int sign;
	int result;

	sign = 1;
	result = 0;
	while (*str != '\0')
	{
		while (*str > '9' && *str <= '~')
			return (result * sign);
		while (*str == '\t' || *str == '\n' || *str == '\v'
			|| *str == '\f' || *str == '\r' || *str == ' ' || *str == '+')
			str++;
		if (*str == '-')
		{
			sign = -1;
			str++;
		}
		while (*str >= '0' && *str <= '9')
		{
			result = (*str - '0') + (result * 10);
			str++;
		}
	}
	return (result * sign);
}
