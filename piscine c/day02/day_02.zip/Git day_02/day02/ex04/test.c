/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: edoll <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/06 16:37:14 by edoll             #+#    #+#             */
/*   Updated: 2019/06/07 19:39:29 by edoll            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
void		ft_putchar(char c)
{
	write(1, &c, 1);
}

void		ft_print_comb(void)
{
	int n;

	n = 0;
	while (n++ <= 999)
	{
		if ((n / 100) < ((n % 100) / 10) && ((n % 100) / 10) < (n % 10))
		{
			ft_putchar((n / 100) + 48);
			ft_putchar(((n % 100) / 10) + 48);
			ft_putchar((n % 10) + 48);
			if (n < 789)
			{
				ft_putchar(',');
				ft_putchar(' ');
			}
		}
	}
}
int main()
{
ft_print_comb();
}
