/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dvictor <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/09 15:25:05 by dvictor           #+#    #+#             */
/*   Updated: 2019/06/09 17:46:32 by edoll            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_putchar(char c);

int		ft_line_zero(int x, int y)
{
	int b;

	if ((x > 1) && (y == 1))
	{
		b = x;
		ft_putchar('o');
		while (b-- > (x - (x - 2)))
			ft_putchar('-');
		ft_putchar('o');
		ft_putchar('\n');
	}
	else if ((x == 1) && (y > 1))
	{
		b = y;
		ft_putchar('o');
		ft_putchar('\n');
		while (b-- > (y - (y - 2)))
		{
			ft_putchar('|');
			ft_putchar('\n');
		}
		ft_putchar('o');
		ft_putchar('\n');
	}
	return (0);
}

int		ft_line_one(int x, int y)
{
	int b;

	b = x;
	if ((x > 1) && (y > 1))
	{
		ft_putchar('o');
		if (x >= 2)
		{
			while (b > (x - (x - 2)))
			{
				ft_putchar('-');
				b--;
			}
		}
		ft_putchar('o');
		ft_putchar('\n');
	}
	return (0);
}

int		ft_line_two(int x, int y)
{
	int a;
	int b;

	a = 0;
	b = x;
	if ((x > 1) && (y > 1))
	{
		while (a < y - 2)
		{
			ft_putchar('|');
			if (x >= 2)
			{
				while (b > (x - (x - 2)))
				{
					ft_putchar(' ');
					b--;
				}
			}
			b = x;
			ft_putchar('|');
			ft_putchar('\n');
			a++;
		}
	}
	return (0);
}

int		ft_line_three(int x, int y)
{
	int b;

	b = x;
	if ((x > 1) && (y > 1))
	{
		ft_putchar('o');
		if (x >= 2)
		{
			while (b > (x - (x - 2)))
			{
				ft_putchar('-');
				b--;
			}
		}
		ft_putchar('o');
		ft_putchar('\n');
	}
	return (0);
}

int		rush(int x, int y)
{
	if ((x == 1) && (y == 1))
	{
		ft_putchar('o');
		ft_putchar('\n');
	}
	else
	{
		ft_line_zero(x, y);
		ft_line_one(x, y);
		ft_line_two(x, y);
		ft_line_three(x, y);
	}
	return (0);
}
