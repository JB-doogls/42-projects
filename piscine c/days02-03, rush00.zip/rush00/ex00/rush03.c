/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dvictor <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/09 16:39:25 by dvictor           #+#    #+#             */
/*   Updated: 2019/06/09 17:44:18 by dvictor          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_putchar(char c);

int		ft_line_zero(int x, int y)
{
	int b;

	if ((x > 1) && (y == 1))
	{
		b = x;
		ft_putchar('A');
		while (b-- > (x - (x - 2)))
			ft_putchar('B');
		ft_putchar('C');
		ft_putchar('\n');
	}
	else if ((x == 1) && (y > 1))
	{
		b = y;
		ft_putchar('A');
		ft_putchar('\n');
		while (b-- > (y - (y - 2)))
		{
			ft_putchar('B');
			ft_putchar('\n');
		}
		ft_putchar('A');
		ft_putchar('\n');
	}
	return (0);
}

int		ft_line_one(int x, int y)
{
	int b;

	b = x;
	if ((x > 1) && (y > 1))
	{
		ft_putchar('A');
		if (x >= 2)
		{
			while (b > (x - (x - 2)))
			{
				ft_putchar('B');
				b--;
			}
		}
		ft_putchar('C');
		ft_putchar('\n');
	}
	return (0);
}

int		ft_line_two(int x, int y)
{
	int a;
	int b;

	a = 0;
	b = x;
	if ((x > 1) && (y > 1))
	{
		while (a < y - 2)
		{
			ft_putchar('B');
			if (x >= 2)
			{
				while (b > (x - (x - 2)))
				{
					ft_putchar(' ');
					b--;
				}
			}
			b = x;
			ft_putchar('B');
			ft_putchar('\n');
			a++;
		}
	}
	return (0);
}

int		ft_line_three(int x, int y)
{
	int b;

	b = x;
	if ((x > 1) && (y > 1))
	{
		ft_putchar('A');
		if (x >= 2)
		{
			while (b > (x - (x - 2)))
			{
				ft_putchar('B');
				b--;
			}
		}
		ft_putchar('C');
		ft_putchar('\n');
	}
	return (0);
}

int		rush(int x, int y)
{
	if ((x == 1) && (y == 1))
	{
		ft_putchar('A');
		ft_putchar('\n');
	}
	else
	{
		ft_line_zero(x, y);
		ft_line_one(x, y);
		ft_line_two(x, y);
		ft_line_three(x, y);
	}
	return (0);
}
